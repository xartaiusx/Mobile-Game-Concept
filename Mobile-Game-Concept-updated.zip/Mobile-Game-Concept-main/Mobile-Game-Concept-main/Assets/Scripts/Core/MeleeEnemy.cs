
using UnityEngine;

namespace Game.Core
{
    public class MeleeEnemy : BaseEnemy
    {
        protected override void PerformAttack()
        {
            if (target == null) return;
            var bc = target.GetComponent<BaseCharacter>();
            if (bc != null) bc.TakeDamage(contactDamage);
        }
    }
}
