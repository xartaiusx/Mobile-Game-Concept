
using UnityEngine;

namespace Game.Core
{
    [RequireComponent(typeof(CharacterController))]
    public class PlayerController : MonoBehaviour
    {
        [Header("Movement")]
        [SerializeField] float moveSpeed = 6f;
        [SerializeField] float gravity = -20f;
        [SerializeField] float jumpHeight = 1.2f;

        [Header("Combat")]
        [SerializeField] int baseDamage = 6;
        [SerializeField] float attackRange = 1.6f;
        [SerializeField] float attackCooldown = 0.4f;

        private CharacterController controller;
        private Vector3 velocity;
        private float lastAttackTime = -999f;
        private Camera mainCam;
        private BaseCharacter character;

        private void Awake()
        {
            controller = GetComponent<CharacterController>();
            mainCam = Camera.main;
            character = GetComponent<BaseCharacter>();
        }

        private void Start()
        {
            var pm = PlayerManager.Instance;
            if (pm != null) pm.RegisterPlayer(transform);
        }

        private void Update()
        {
            HandleMovement();
            if (Input.GetButtonDown("Fire1")) TryAttack();
        }

        private void HandleMovement()
        {
            float h = Input.GetAxis("Horizontal");
            float v = Input.GetAxis("Vertical");

            Vector3 move = new Vector3(h, 0, v);
            if (move.sqrMagnitude > 0.0001f)
            {
                // Align to camera forward if present
                if (mainCam != null)
                {
                    Vector3 camForward = mainCam.transform.forward;
                    camForward.y = 0;
                    camForward.Normalize();
                    Vector3 camRight = new Vector3(camForward.z, 0, -camForward.x);
                    move = camForward * v + camRight * h;
                }
                transform.rotation = Quaternion.LookRotation(move.normalized);
            }

            controller.Move(move.normalized * moveSpeed * Time.deltaTime);

            // gravity + jump (simple tap)
            if (controller.isGrounded && velocity.y < 0) velocity.y = -2f;
            if (controller.isGrounded && Input.GetButtonDown("Jump")) velocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);
            velocity.y += gravity * Time.deltaTime;
            controller.Move(velocity * Time.deltaTime);
        }

        private void TryAttack()
        {
            if (Time.time - lastAttackTime < attackCooldown) return;
            lastAttackTime = Time.time;

            Collider[] hits = Physics.OverlapSphere(transform.position + transform.forward * attackRange * 0.5f, attackRange);
            foreach (var hit in hits)
            {
                var enemy = hit.GetComponent<BaseEnemy>();
                if (enemy != null)
                {
                    int dmg = baseDamage + (character != null ? character.Strength / 2 : 0);
                    enemy.TakeDamage(dmg);
                }
            }
        }
    }
}
