
using UnityEngine;
using System;

namespace Game.Core
{
    [RequireComponent(typeof(CharacterController))]
    public abstract class BaseEnemy : MonoBehaviour
    {
        [Header("Stats")]
        [SerializeField] protected int maxHealth = 20;
        [SerializeField] protected int currentHealth = 20;
        [SerializeField] protected int contactDamage = 5;

        [Header("AI")]
        [SerializeField] protected float moveSpeed = 3f;
        [SerializeField] protected float gravity = -20f;
        [SerializeField] protected float attackCooldown = 1.2f;
        [SerializeField] protected float attackRange = 1.5f;

        protected float lastAttackTime = -999f;
        protected CharacterController controller;
        protected Transform target;
        protected Vector3 velocity;

        public event Action<BaseEnemy> OnEnemyDefeated;

        protected virtual void Awake()
        {
            controller = GetComponent<CharacterController>();
        }

        protected virtual void Start()
        {
            var pm = PlayerManager.Instance;
            if (pm != null) target = pm.GetPlayerTransform();
        }

        protected virtual void Update()
        {
            if (target == null) return;
            // Gravity
            if (controller.isGrounded && velocity.y < 0) velocity.y = -2f;
            velocity.y += gravity * Time.deltaTime;

            Vector3 flatToTarget = (new Vector3(target.position.x, transform.position.y, target.position.z) - transform.position);
            Vector3 dir = flatToTarget.normalized;

            if (flatToTarget.magnitude > attackRange)
            {
                controller.Move(dir * moveSpeed * Time.deltaTime);
                transform.rotation = Quaternion.LookRotation(dir);
            }
            else
            {
                TryAttack();
            }

            controller.Move(velocity * Time.deltaTime);
        }

        protected virtual void TryAttack()
        {
            if (Time.time - lastAttackTime < attackCooldown) return;
            lastAttackTime = Time.time;
            PerformAttack();
        }

        protected abstract void PerformAttack();

        public virtual void TakeDamage(int amount)
        {
            currentHealth = Mathf.Max(0, currentHealth - Mathf.Max(0, amount));
            if (currentHealth == 0) Die();
        }

        protected virtual void Die()
        {
            OnEnemyDefeated?.Invoke(this);
            Destroy(gameObject);
        }
    }
}
