
using UnityEngine;

namespace Game.Core
{
    public class Mage : BaseCharacter
    {
        [SerializeField] int healthPerStamina = 8;
        public override void InitializeStats()
        {
            CharacterName = "Mage";
            Strength = 3;
            Stamina = 5;
            Intelligence = 10;
            maxHealth = Mathf.Max(1, Stamina * healthPerStamina);
            currentHealth = maxHealth;
        }
    }
}
