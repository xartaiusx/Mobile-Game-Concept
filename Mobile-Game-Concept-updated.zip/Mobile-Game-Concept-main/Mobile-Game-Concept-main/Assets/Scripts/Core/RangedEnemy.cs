
using UnityEngine;

namespace Game.Core
{
    public class RangedEnemy : BaseEnemy
    {
        [Header("Ranged")]
        [SerializeField] private Projectile projectilePrefab;
        [SerializeField] private float projectileSpeed = 12f;
        [SerializeField] private int projectileDamage = 5;
        [SerializeField] private Transform firePoint;

        protected override void PerformAttack()
        {
            if (target == null || projectilePrefab == null) return;
            Transform fp = firePoint != null ? firePoint : transform;
            Projectile p = Instantiate(projectilePrefab, fp.position + transform.forward * 0.5f, Quaternion.identity);
            p.Initialize(target.position, projectileSpeed, projectileDamage);
        }
    }
}
