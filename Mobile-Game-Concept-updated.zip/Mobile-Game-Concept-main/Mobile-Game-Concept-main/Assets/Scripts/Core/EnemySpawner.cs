
using UnityEngine;
using System.Collections.Generic;

namespace Game.Core
{
    public class EnemySpawner : MonoBehaviour
    {
        [SerializeField] private BaseEnemy enemyPrefab;
        [SerializeField] private int maxEnemies = 6;
        [SerializeField] private float spawnInterval = 3f;
        [SerializeField] private float spawnRadius = 10f;

        private readonly List<BaseEnemy> active = new List<BaseEnemy>();
        private float lastSpawnTime = -999f;
        private Transform player;

        private void Start()
        {
            var pm = PlayerManager.Instance;
            player = pm != null ? pm.GetPlayerTransform() : null;
        }

        private void Update()
        {
            if (enemyPrefab == null) return;
            if (active.RemoveAll(e => e == null) > 0) { } // cleanup
            if (active.Count >= maxEnemies) return;
            if (Time.time - lastSpawnTime < spawnInterval) return;

            Vector3 origin = player != null ? player.position : transform.position;
            Vector2 rnd = Random.insideUnitCircle.normalized * spawnRadius;
            Vector3 pos = new Vector3(origin.x + rnd.x, origin.y, origin.z + rnd.y);
            var e = Instantiate(enemyPrefab, pos, Quaternion.identity);
            e.OnEnemyDefeated += HandleEnemyDefeated;
            active.Add(e);
            lastSpawnTime = Time.time;
        }

        private void HandleEnemyDefeated(BaseEnemy e)
        {
            if (e != null) e.OnEnemyDefeated -= HandleEnemyDefeated;
        }
    }
}
