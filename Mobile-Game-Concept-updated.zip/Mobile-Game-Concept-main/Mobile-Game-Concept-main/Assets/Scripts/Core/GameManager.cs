
using UnityEngine;

namespace Game.Core
{
    public enum CharacterClass { Fighter, Mage, Archer, Healer }

    public class GameManager : MonoBehaviour
    {
        [SerializeField] private GameObject fighterPrefab;
        [SerializeField] private GameObject magePrefab;
        [SerializeField] private GameObject archerPrefab;
        [SerializeField] private GameObject healerPrefab;

        [SerializeField] private Transform playerSpawnPoint;

        private void Start()
        {
            var selected = (CharacterClass)PlayerPrefs.GetInt("SelectedClass", (int)CharacterClass.Fighter);
            GameObject prefab = GetPrefab(selected);
            if (prefab == null)
            {
                Debug.LogError("Selected class prefab not assigned. Falling back to Fighter.");
                prefab = fighterPrefab;
            }
            var spawn = playerSpawnPoint != null ? playerSpawnPoint.position : Vector3.zero;
            var go = Instantiate(prefab, spawn, Quaternion.identity);
            var pm = PlayerManager.Instance;
            if (pm != null) pm.RegisterPlayer(go.transform);
        }

        private GameObject GetPrefab(CharacterClass c)
        {
            switch (c)
            {
                case CharacterClass.Fighter: return fighterPrefab;
                case CharacterClass.Mage: return magePrefab;
                case CharacterClass.Archer: return archerPrefab;
                case CharacterClass.Healer: return healerPrefab;
                default: return fighterPrefab;
            }
        }
    }
}
