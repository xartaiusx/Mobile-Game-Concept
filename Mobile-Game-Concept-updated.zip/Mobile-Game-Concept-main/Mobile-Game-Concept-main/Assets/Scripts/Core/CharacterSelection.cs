
using UnityEngine;

namespace Game.Core
{
    public class CharacterSelection : MonoBehaviour
    {
        public void SelectFighter() => Save(CharacterClass.Fighter);
        public void SelectMage() => Save(CharacterClass.Mage);
        public void SelectArcher() => Save(CharacterClass.Archer);
        public void SelectHealer() => Save(CharacterClass.Healer);

        private void Save(CharacterClass c)
        {
            PlayerPrefs.SetInt("SelectedClass", (int)c);
            PlayerPrefs.Save();
        }
    }
}
