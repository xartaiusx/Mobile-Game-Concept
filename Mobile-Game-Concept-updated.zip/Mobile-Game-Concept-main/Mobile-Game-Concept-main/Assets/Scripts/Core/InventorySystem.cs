
using UnityEngine;
using System.Collections.Generic;

namespace Game.Core
{
    [CreateAssetMenu(menuName = "Game/ItemDefinition")]
    public class ItemDefinition : ScriptableObject
    {
        public string itemId;
        public string displayName;
        public Sprite icon;
        public int maxStack = 99;
    }

    public class InventoryItem
    {
        public ItemDefinition def;
        public int count;
    }

    /// <summary>
    /// Minimal inventory implementation sufficient to compile and use in UI later.
    /// </summary>
    public class InventorySystem : MonoBehaviour
    {
        [SerializeField] private int capacity = 24;
        private readonly List<InventoryItem> items = new List<InventoryItem>();

        public bool AddItem(ItemDefinition def, int count = 1)
        {
            if (def == null || count <= 0) return false;

            // Find existing stack
            foreach (var it in items)
            {
                if (it.def == def && it.count < def.maxStack)
                {
                    int canAdd = Mathf.Min(def.maxStack - it.count, count);
                    it.count += canAdd;
                    count -= canAdd;
                    if (count <= 0) return true;
                }
            }
            // Add new stacks as needed
            while (count > 0 && items.Count < capacity)
            {
                int add = Mathf.Min(def.maxStack, count);
                items.Add(new InventoryItem { def = def, count = add });
                count -= add;
            }
            return count == 0;
        }

        public bool RemoveItem(ItemDefinition def, int count = 1)
        {
            if (def == null || count <= 0) return false;
            for (int i = items.Count - 1; i >= 0 && count > 0; i--)
            {
                var it = items[i];
                if (it.def != def) continue;
                int take = Mathf.Min(it.count, count);
                it.count -= take;
                count -= take;
                if (it.count <= 0) items.RemoveAt(i);
            }
            return count == 0;
        }

        public IReadOnlyList<InventoryItem> Items => items;
    }
}
