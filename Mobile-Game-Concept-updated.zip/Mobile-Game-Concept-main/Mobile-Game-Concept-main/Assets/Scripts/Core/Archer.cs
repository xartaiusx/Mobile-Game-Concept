
using UnityEngine;

namespace Game.Core
{
    public class Archer : BaseCharacter
    {
        [SerializeField] int healthPerStamina = 10;
        public override void InitializeStats()
        {
            CharacterName = "Archer";
            Strength = 7;
            Stamina = 7;
            Intelligence = 5;
            maxHealth = Mathf.Max(1, Stamina * healthPerStamina);
            currentHealth = maxHealth;
        }
    }
}
