
using UnityEngine;

namespace Game.Core
{
    [System.Serializable]
    public struct LootEntry
    {
        public ItemDefinition item;
        [Range(0f,1f)] public float dropChance;
        public int minCount;
        public int maxCount;
    }

    /// <summary>
    /// Simple loot table that rolls once on death.
    /// </summary>
    public class LootSystem : MonoBehaviour
    {
        [SerializeField] private LootEntry[] table;

        public void Drop(InventorySystem inventory)
        {
            if (inventory == null || table == null) return;
            foreach (var e in table)
            {
                if (e.item == null || e.dropChance <= 0f) continue;
                if (Random.value <= e.dropChance)
                {
                    int c = Random.Range(e.minCount, e.maxCount + 1);
                    inventory.AddItem(e.item, c);
                }
            }
        }
    }
}
