
using UnityEngine;

namespace Game.Core
{
    public class Fighter : BaseCharacter
    {
        [SerializeField] int healthPerStamina = 12;
        public override void InitializeStats()
        {
            CharacterName = "Fighter";
            Strength = 10;
            Stamina = 8;
            Intelligence = 3;
            maxHealth = Mathf.Max(1, Stamina * healthPerStamina);
            currentHealth = maxHealth;
        }
    }
}
