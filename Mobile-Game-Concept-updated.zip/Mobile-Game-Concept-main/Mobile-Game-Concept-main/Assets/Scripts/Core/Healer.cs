
using UnityEngine;

namespace Game.Core
{
    public class Healer : BaseCharacter
    {
        [SerializeField] int healthPerStamina = 9;
        public override void InitializeStats()
        {
            CharacterName = "Healer";
            Strength = 4;
            Stamina = 6;
            Intelligence = 9;
            maxHealth = Mathf.Max(1, Stamina * healthPerStamina);
            currentHealth = maxHealth;
        }
    }
}
