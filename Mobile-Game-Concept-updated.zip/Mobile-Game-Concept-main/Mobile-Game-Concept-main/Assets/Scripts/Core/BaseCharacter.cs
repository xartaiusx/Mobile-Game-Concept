
using UnityEngine;
using System;

namespace Game.Core
{
    /// <summary>
    /// Abstract base for all characters. Provides common stats and health handling.
    /// </summary>
    public abstract class BaseCharacter : MonoBehaviour
    {
        [field: SerializeField] public string CharacterName { get; set; } = "Unnamed";
        [field: SerializeField] public int Level { get; protected set; } = 1;

        [SerializeField] protected int strength = 1;
        [SerializeField] protected int stamina = 1;
        [SerializeField] protected int intelligence = 1;

        [SerializeField] protected int maxHealth = 10;
        [SerializeField] protected int currentHealth = 10;

        public int Strength { get => strength; set => strength = Mathf.Max(0, value); }
        public int Stamina { get => stamina; set => stamina = Mathf.Max(0, value); }
        public int Intelligence { get => intelligence; set => intelligence = Mathf.Max(0, value); }

        public int MaxHealth => maxHealth;
        public int CurrentHealth => currentHealth;

        public event Action<BaseCharacter> OnDeath;

        protected virtual void Awake()
        {
            InitializeStats();
            currentHealth = Mathf.Clamp(currentHealth, 0, maxHealth);
            if (currentHealth <= 0) currentHealth = maxHealth;
        }

        public virtual void InitializeStats() { }

        public virtual void LevelUp()
        {
            Level++;
            Strength += 1;
            Stamina += 1;
            Intelligence += 1;
            maxHealth = Mathf.Max(maxHealth, Stamina * 10);
            currentHealth = maxHealth;
        }

        public virtual void TakeDamage(int amount)
        {
            currentHealth = Mathf.Max(0, currentHealth - Mathf.Max(0, amount));
            if (currentHealth == 0) Die();
        }

        public virtual void Heal(int amount)
        {
            currentHealth = Mathf.Min(maxHealth, currentHealth + Mathf.Max(0, amount));
        }

        protected virtual void Die()
        {
            OnDeath?.Invoke(this);
            Destroy(gameObject);
        }
    }
}
