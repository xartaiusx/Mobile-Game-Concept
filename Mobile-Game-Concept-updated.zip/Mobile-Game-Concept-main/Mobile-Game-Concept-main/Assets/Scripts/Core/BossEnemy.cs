
using UnityEngine;
using System.Collections;

namespace Game.Core
{
    public enum BossAttackMode { Melee, Ranged }

    public class BossEnemy : BaseEnemy
    {
        [Header("Boss Settings")]
        [SerializeField] private BossAttackMode attackMode = BossAttackMode.Melee;
        [SerializeField] private Projectile projectilePrefab;
        [SerializeField] private float projectileSpeed = 14f;
        [SerializeField] private int projectileDamage = 8;
        [SerializeField] private float burstInterval = 0.2f;
        [SerializeField] private int burstCount = 3;

        protected override void PerformAttack()
        {
            switch (attackMode)
            {
                case BossAttackMode.Melee:
                    DoMelee();
                    break;
                case BossAttackMode.Ranged:
                    StartCoroutine(BurstRanged());
                    break;
            }
        }

        private void DoMelee()
        {
            if (target == null) return;
            var bc = target.GetComponent<BaseCharacter>();
            if (bc != null) bc.TakeDamage(contactDamage * 2);
        }

        private IEnumerator BurstRanged()
        {
            if (target == null || projectilePrefab == null) yield break;
            for (int i = 0; i < burstCount; i++)
            {
                Projectile p = Instantiate(projectilePrefab, transform.position + transform.forward * 0.6f, Quaternion.identity);
                p.Initialize(target.position, projectileSpeed, projectileDamage);
                yield return new WaitForSeconds(burstInterval);
            }
        }
    }
}
